 # if __name__ == "__main__":
    #     # Configure matplotlib to use the TkAgg backend
    #     import matplotlib
    #     matplotlib.use("TkAgg")
    #     import matplotlib.pyplot as plt
        
    #     # Start the application
    #     app = FinanceApp()
    #     app.mainloop()